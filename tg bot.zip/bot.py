"""
YouTube -> Telegram avtomatik post bot.

Ishlash tartibi:
1. YouTube kanalning RSS lentasini o'qiydi (API kalit shart emas).
2. Oxirgi joylangan video ID sini last_video_id.txt faylidan o'qiydi.
3. Agar yangi video topilsa - Telegram kanalga video linkini yuboradi
   (Telegram o'zi avtomatik ravishda sarlavha + rasm/thumbnaili bilan preview
   ko'rsatadi), so'ng yangi video ID ni faylga yozib qo'yadi.

Bu skript BIR MARTA ishga tushadi va tugaydi - shuning uchun uni bulutda
(GitHub Actions, cron, va h.k.) har soatda/har necha daqiqada qayta-qayta
ishga tushirish kerak. Qo'shimcha ma'lumot uchun README.md ga qarang.
"""

import os
import sys
import re
import urllib.request
import xml.etree.ElementTree as ET

# ---------- Sozlamalar (Environment Variables orqali beriladi) ----------
BOT_TOKEN = os.environ.get("TG_BOT_TOKEN")            # Telegram bot tokeni
CHANNEL_ID = os.environ.get("TG_CHANNEL_ID")           # Masalan: @mening_kanalim yoki -100123456789
YT_CHANNEL_ID = os.environ.get("YT_CHANNEL_ID")         # YouTube kanal ID (UCxxxxxxxx bilan boshlanadi)
STATE_FILE = os.environ.get("STATE_FILE", "last_video_id.txt")

YT_RSS_URL = f"https://www.youtube.com/feeds/videos.xml?channel_id={YT_CHANNEL_ID}"


def get_latest_video():
    """YouTube RSS dan eng so'nggi videoni oladi: (video_id, title, url)."""
    with urllib.request.urlopen(YT_RSS_URL, timeout=20) as resp:
        data = resp.read()

    ns = {
        "atom": "http://www.w3.org/2005/Atom",
        "yt": "http://www.youtube.com/xml/schemas/2015",
    }
    root = ET.fromstring(data)
    entry = root.find("atom:entry", ns)
    if entry is None:
        return None

    video_id = entry.find("yt:videoId", ns).text
    title = entry.find("atom:title", ns).text
    link = entry.find("atom:link", ns).attrib.get("href")
    return video_id, title, link


def read_last_id():
    if not os.path.exists(STATE_FILE):
        return None
    with open(STATE_FILE, "r", encoding="utf-8") as f:
        return f.read().strip() or None


def write_last_id(video_id):
    with open(STATE_FILE, "w", encoding="utf-8") as f:
        f.write(video_id)


def send_to_telegram(title, url):
    """Telegramga xabar yuboradi. Link preview orqali rasm/thumbnail avtomatik chiqadi."""
    api_url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"
    text = f"🎬 {title}\n\n{url}"
    payload = {
        "chat_id": CHANNEL_ID,
        "text": text,
        "disable_web_page_preview": "false",
    }
    data = urllib.parse.urlencode(payload).encode()
    req = urllib.request.Request(api_url, data=data, method="POST")
    with urllib.request.urlopen(req, timeout=20) as resp:
        result = resp.read().decode()
        return result


import urllib.parse  # noqa: E402 (yuqorida ishlatilgani uchun shu yerda import qilindi)


def main():
    missing = [name for name, val in [
        ("TG_BOT_TOKEN", BOT_TOKEN),
        ("TG_CHANNEL_ID", CHANNEL_ID),
        ("YT_CHANNEL_ID", YT_CHANNEL_ID),
    ] if not val]
    if missing:
        print(f"Xato: quyidagi environment variable'lar berilmagan: {', '.join(missing)}")
        sys.exit(1)

    latest = get_latest_video()
    if latest is None:
        print("RSS lentada video topilmadi.")
        return

    video_id, title, url = latest
    last_id = read_last_id()

    if video_id == last_id:
        print("Yangi video yo'q. Hech narsa qilinmadi.")
        return

    print(f"Yangi video topildi: {title} ({url})")
    send_to_telegram(title, url)
    write_last_id(video_id)
    print("Telegram kanalga muvaffaqiyatli joylandi.")


if __name__ == "__main__":
    main()
